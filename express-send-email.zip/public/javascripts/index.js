const input = document.getElementById('input-email')
var nome = ''
var email = ''


async function teste(){
}
teste()